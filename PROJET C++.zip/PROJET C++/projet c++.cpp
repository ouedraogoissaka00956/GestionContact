#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <string>

struct Contact {
    std::string nom;
    std::string telephone;
    std::string email;
    std::string adresse;
};

class GestionContacts {
private:
    std::vector<Contact> contacts;

public:
    void ajouterContact(const Contact& contact) {
        contacts.push_back(contact);
        std::cout << "Contact ajout� avec succ�s.\n";
    }

    void modifierContact(const std::string& nom) {
        for (auto& contact : contacts) {
            if (contact.nom == nom) {
                std::cout << "Modifier le num�ro de t�l�phone: ";
                std::cin >> contact.telephone;
                std::cout << "Modifier l'email: ";
                std::cin >> contact.email;
                std::cout << "Modifier l'adresse: ";
                std::cin.ignore();
                std::getline(std::cin, contact.adresse);
                std::cout << "Contact modifi� avec succ�s.\n";
                return;
            }
        }
        std::cout << "Contact introuvable.\n";
    }

    void supprimerContact(const std::string& nom) {
        auto it = std::remove_if(contacts.begin(), contacts.end(),
                                 [&nom](const Contact& contact) { return contact.nom == nom; });
        if (it != contacts.end()) {
            contacts.erase(it, contacts.end());
            std::cout << "Contact supprim� avec succ�s.\n";
        } else {
            std::cout << "Contact introuvable.\n";
        }
    }

    void rechercherContact(const std::string& nom) const {
        for (const auto& contact : contacts) {
            if (contact.nom == nom) {
                std::cout << "Nom: " << contact.nom << "\n"
                          << "T�l�phone: " << contact.telephone << "\n"
                          << "Email: " << contact.email << "\n"
                          << "Adresse: " << contact.adresse << "\n";
                return;
            }
        }
        std::cout << "Contact introuvable.\n";
    }

    void trierContactsParNom() {
        std::sort(contacts.begin(), contacts.end(),
                  [](const Contact& a, const Contact& b) { return a.nom < b.nom; });
        std::cout << "Contacts tri�s par nom.\n";
    }

    void sauvegarderDansFichier(const std::string& nomFichier) const {
        std::ofstream fichier(nomFichier);
        if (fichier) {
            for (const auto& contact : contacts) {
                fichier << contact.nom << "," << contact.telephone << ","
                        << contact.email << "," << contact.adresse << "\n";
            }
            std::cout << "Contacts sauvegard�s dans le fichier.\n";
        } else {
            std::cout << "Erreur lors de la sauvegarde dans le fichier.\n";
        }
    }

    void chargerDepuisFichier(const std::string& nomFichier) {
        std::ifstream fichier(nomFichier);
        if (fichier) {
            contacts.clear();
            std::string ligne;
            while (std::getline(fichier, ligne)) {
                Contact contact;
                size_t pos = 0;
                pos = ligne.find(',');
                contact.nom = ligne.substr(0, pos);
                ligne.erase(0, pos + 1);

                pos = ligne.find(',');
                contact.telephone = ligne.substr(0, pos);
                ligne.erase(0, pos + 1);

                pos = ligne.find(',');
                contact.email = ligne.substr(0, pos);
                ligne.erase(0, pos + 1);

                contact.adresse = ligne;
                contacts.push_back(contact);
            }
            std::cout << "Contacts charg�s depuis le fichier.\n";
        } else {
            std::cout << "Erreur lors du chargement du fichier.\n";
        }
    }
};

int main() {
    GestionContacts gestion;
    int choix;
    do {
        std::cout << "\n1. Ajouter un contact\n"
                  << "2. Modifier un contact\n"
                  << "3. Supprimer un contact\n"
                  << "4. Rechercher un contact\n"
                  << "5. Trier les contacts\n"
                  << "6. Sauvegarder dans un fichier\n"
                  << "7. Charger depuis un fichier\n"
                  << "8. Quitter\n"
                  << "Votre choix: ";
        std::cin >> choix;
        std::cin.ignore();

        switch (choix) {
        case 1: {
            Contact contact;
            std::cout << "Nom: ";
            std::getline(std::cin, contact.nom);
            std::cout << "T�l�phone: ";
            std::cin >> contact.telephone;
            std::cout << "Email: ";
            std::cin >> contact.email;
            std::cout << "Adresse: ";
            std::cin.ignore();
            std::getline(std::cin, contact.adresse);
            gestion.ajouterContact(contact);
            break;
        }
        case 2: {
            std::string nom;
            std::cout << "Nom du contact � modifier: ";
            std::getline(std::cin, nom);
            gestion.modifierContact(nom);
            break;
        }
        case 3: {
            std::string nom;
            std::cout << "Nom du contact � supprimer: ";
            std::getline(std::cin, nom);
            gestion.supprimerContact(nom);
            break;
        }
        case 4: {
            std::string nom;
            std::cout << "Nom du contact � rechercher: ";
            std::getline(std::cin, nom);
            gestion.rechercherContact(nom);
            break;
        }
        case 5:
            gestion.trierContactsParNom();
            break;
        case 6: {
            std::string nomFichier;
            std::cout << "Nom du fichier de sauvegarde: ";
            std::cin >> nomFichier;
            gestion.sauvegarderDansFichier(nomFichier);
            break;
        }
        case 7: {
            std::string nomFichier;
            std::cout << "Nom du fichier � charger: ";
            std::cin >> nomFichier;
            gestion.chargerDepuisFichier(nomFichier);
            break;
        }
        case 8:
            std::cout << "Au revoir !\n";
            break;
        default:
            std::cout << "Choix invalide. Veuillez r�essayer.\n";
        }
    } while (choix != 8);

    return 0;
}
